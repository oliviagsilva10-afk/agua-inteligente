
from flask import Flask, render_template, request, redirect
import mysql.connector
app = Flask(__name__)

def conectar():
    return mysql.connector.connect(
    host="localhost",
    port=3307,
    user="root",
    password="admin",
    database="agua_inteligente"
    )

@app.route("/")
def login():
    return render_template("login.html")

@app.route("/login", methods=["POST"])
def entrar():
    nome = request.form["nome"]
    senha = request.form["senha"]

    banco = conectar()
    cursor = banco.cursor()

    cursor.execute(
        "SELECT * FROM usuario WHERE id_nome = %s AND id_senha = %s",
        (nome, senha)
    )

    usuario = cursor.fetchone()
    cursor.close()
    banco.close()

    if usuario:
        return redirect("/inicio")

    return "Nome ou senha incorretos!"

@app.route("/inicio")
def inicio():
    return render_template("inicio.html")

@app.route("/sensores")
def sensores():
    banco = conectar()
    cursor = banco.cursor()
    cursor.execute("SELECT * FROM sensores")
    dados = cursor.fetchall()
    cursor.close()
    banco.close()
    return render_template("sensores.html", sensores=dados)


if __name__ == "__main__":
   app.run(debug=True)
